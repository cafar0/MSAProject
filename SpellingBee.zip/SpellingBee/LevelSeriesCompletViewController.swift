//
//  LevelSeriesCompletViewController.swift
//  SpellingBee
//
//  Created by Rodina, Calin on 30/12/2016.
//  Copyright © 2016 Rodina, Calin. All rights reserved.
//

import UIKit

class LevelSeriesCompletViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


}
